public class Circle extends Shape implements Comparable<Circle> {
    public double radius;
    public String name;

    public Circle() {
        radius = 1.0;
        name = "circle";
    }

    public Circle(double radius, String name) {
        this.radius = radius;
        this.name = name;
    }

    public double getArea() {
        return Math.PI * radius * radius;
    }

    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    public boolean equals(Object object) {
        if (object instanceof Circle) {
            Circle cir = (Circle) object;
            if (cir.radius == radius && cir.name.length() == name.length()) {
                return true;
            }
            return false;
        } else {
            return false;
        }
    }

    public void set(double radius) {
        this.radius = radius;
    }

    public void set(String name) {
        this.name = name;
    }

    public String toString() {
        return "Name: " + name + " Radius: " + radius;
    }

    public int compareTo(Circle c) {
        if (radius > c.radius) {
            return 1;
        } else if (radius < c.radius) {
            return -1;
        } else {
            return 0;
        }

    }
}
