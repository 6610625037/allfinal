import java.util.Scanner;

public class MixedHex {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter string of hex digits (in pairs): ");
        String input1 = sc.nextLine();
        System.out.print("Enter string of hex digits (in pairs): ");
        String input2 = sc.nextLine();
        System.out.print("Enter a delimiter: ");
        String delim = sc.next();
        sc.close();

        // size = all input char div by 2 + delimiter slots
        String[] output = new String[input1.length() / 2 + input2.length() / 2 + (input1.length() + input2.length()) / 2
                - 1];

        int count_1 = 0;
        int count_2 = 0;
        for (int i = 0; i < output.length; i += 2) {
            if (count_1 * 2 < input1.length()) {
                output[i] = input1.substring(count_1 * 2, count_1 * 2 + 2);
                count_1++;
                i += 2;
            }
            if (count_2 * 2 < input2.length()) {
                output[i] = input2.substring(count_2 * 2, count_2 * 2 + 2);
                count_2++;
            }
        }
        // add delimiter in output array
        for (int i = 1; i < output.length; i += 2) {
            output[i] = delim;
        }

        for (int i = 0; i < output.length; i++) {
            System.out.print(output[i]);
        }

    }
}
