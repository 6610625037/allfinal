/**
 *
 * @author 6610685247 <6610685247@cn103>
 */
public class Rectangle extends Shape implements Comparable<Rectangle> {

    private double width;
    private double height;

    public Rectangle() {
    }

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    @Override
    public double getArea() {
        return width * height;
    }

    @Override
    public double getPerimeter() {
        return 2 * width * height;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj instanceof Rectangle) {
            return ((Rectangle) obj).getHeight() == getHeight() && ((Rectangle) obj).getWidth() == getWidth();
        } else {
            return false;
        }
    }

    @Override
    public int compareTo(Rectangle r) {
        if (r.getArea() > getArea()) {
            return 1;
        } else if (r.getArea() < getArea()) {
            return -1;
        } else {
            return 0;
        }
    }
}
