/**
 *
 * @author 6610685247 <6610685247@cn103>
 */
public class Octagons extends Shape implements Comparable<Octagons> {
    private double side;

    public Octagons() {
        this(1);
    }

    public Octagons(double side) {
        this.side = side;
    }

    public double getSide() {
        return side;
    }

    public void setSide(double side) {
        this.side = side;
    }

    @Override
    public double getArea() {
        return 2 * (1 + Math.sqrt(2)) * side * side;
    }

    @Override
    public double getPerimeter() {
        return 8 * side;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj instanceof Octagons) {
            return ((Octagons) obj).getSide() == getSide();
        } else {
            return false;
        }
    }

    @Override
    public int compareTo(Octagons oc) {
        if (oc.getSide() > getSide()) {
            return 1;
        } else if (oc.getSide() < getSide()) {
            return -1;
        } else {
            return 0;
        }
    }

}
