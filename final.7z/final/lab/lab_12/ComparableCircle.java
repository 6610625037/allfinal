/**
 *
 * @author 6610685247 <6610685247@cn103>
 */
public class ComparableCircle extends Circle implements Comparable<ComparableCircle> {

    public ComparableCircle(double radius) {
        super(radius);
    }

    @Override
    public int compareTo(ComparableCircle a) {
        if (getArea() > a.getArea()) {
            return 1;
        } else if (getArea() < a.getArea()) {
            return -1;
        } else {
            return 0;
        }
    }

    @Override
    public String toString() {
        return super.toString() + " Area: " + getArea();
    }

}
