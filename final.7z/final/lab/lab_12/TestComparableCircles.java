import java.util.Arrays;

/**
 *
 * @author xxxxxxxxxx <xxxxxxxxxx@cn103>
 */
public class TestComparableCircles {

    public static void main(String[] args) {
        ComparableCircle[] circles = {
            new ComparableCircle(7),
            new ComparableCircle(5),
            new ComparableCircle(1),
            new ComparableCircle(3)
        };

        Arrays.sort(circles);

        // use enhanced loop
        for (Circle circle : circles) {
            System.out.print(circle + " ");
            System.out.println();
        }
    }
}

