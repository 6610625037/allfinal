/**
 *
 * @author xxxxxxxxxx <xxxxxxxxxx@cn103>
 */
public interface Edible {
    /**
     * Describe how to eat
     * @return a String describe how to eat
     */
    public abstract String howToEat();
}

