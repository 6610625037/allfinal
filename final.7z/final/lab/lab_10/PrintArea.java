
/**
 *
 * @author 6610685247 <6610685247@cn103>
 */
import java.util.Scanner;

public class PrintArea {

    // create array of Circle objects with random radius
    public static Circle[] createCircleArray(int n) {
        Circle[] circleArray = new Circle[n];

        for (int i = 0; i < n; i++) {
            circleArray[i] = new Circle(Math.random() * 100);
        }
        return circleArray;
    }

    // create array of Rectangle objects with random width and height
    public static Rectangle[] createRectangleArray(int n) {
        Rectangle[] rectangleArray = new Rectangle[n];

        for (int i = 0; i < n; i++) {
            rectangleArray[i] = new Rectangle(Math.random() * 100, Math.random() * 100);
        }

        return rectangleArray;
    }

    public static void printArea(Shape[] shapeArray) {
        for (int i = 0; i < shapeArray.length; i++) {
            if (shapeArray[i] instanceof Circle) {
                Circle circle = (Circle) shapeArray[i];
                System.out.printf("Circle[%d]: radius: %.2f area: %.2f\n", i, circle.getRadius(), circle.getArea());
            } else if (shapeArray[i] instanceof Rectangle) {
                Rectangle rectangle = (Rectangle) shapeArray[i];
                System.out.printf("Rectangle[%d]: W x H: %.2f x %.2f area: %.2f\n", i, rectangle.getWidth(),
                        rectangle.getHeight(), rectangle.getArea());
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;

        System.out.print("Enter number of objects: ");
        n = sc.nextInt();
        sc.close();

        // create no more than 50 shape objects each
        if (n > 50) {
            return;
        }

        Circle[] circleArray = createCircleArray(n);
        Rectangle[] rectangleArray = createRectangleArray(n);

        printArea(circleArray);
        printArea(rectangleArray);
    }
}
