import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author 6610685247 <6610685247@cn103>
 */
public class FindMaxList {
    static Integer findMaxList(ArrayList<Integer> list) {
        Integer max = list.get(0);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i) > max) {
                max = list.get(i);
            }
        }

        return max;
    }

    static void printList(ArrayList<Integer> list) {
        int size = list.size();

        System.out.print("List: ");
        for (int i = 0; i < size; i++) {
            System.out.print(list.get(i) + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        ArrayList<Integer> list;
        int n, x;
        int max;

        list = new ArrayList<Integer>();
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter n: ");
        n = sc.nextInt();

        for (int i = 0; i < n; i++) {
            System.out.printf("Enter x[%d]: ", i);
            x = sc.nextInt();
            list.add(x);
        }
        sc.close();
        max = findMaxList(list);

        printList(list);
        System.out.println("Max: " + max);
    }
}
