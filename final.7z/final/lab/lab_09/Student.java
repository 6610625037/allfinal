/**
 *
 * @author 6610685247 <6610685247@cn103>
 */
public class Student extends Person {
    private String status;

    public Student() {
        this("freshman");
    }

    public Student(String status) {
        this.status = status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}
