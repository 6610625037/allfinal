/**
 *
 * @author 6610685247 <6610685247@cn103>
 */
public class Employee extends Person {
    private int salary;

    public Employee() {
        this(0);
    }

    public Employee(int amount) {
        salary = amount;
    }

    public void setSalary(int amount) {
        salary = amount;
    }

    public double getSalary() {
        return salary;
    }
}
