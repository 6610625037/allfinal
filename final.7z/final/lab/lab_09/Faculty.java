/**
 *
 * @author 6610685247 <6610685247@cn103>
 */
public class Faculty extends Employee {
    private String officeHour;

    public Faculty() {
        this("8:00 - 16:00");
    }

    public Faculty(String hour) {
        officeHour = hour;
    }

    public void setOfficeHour(String hour) {
        officeHour = hour;
    }

    public String getOfficeHour() {
        return officeHour;
    }

}
