/**
 *
 * @author 6610685247 <6610685247@cn103>
 */
public class Staff extends Employee {
    private String position;

    public Staff() {
        this("office");
    }

    public Staff(String position) {
        this.position = position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getPosition() {
        return position;
    }
}
