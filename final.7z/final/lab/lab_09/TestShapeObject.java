/**
 *
 * @author 6610685247 <6610685247@cn103>
 */
public class TestShapeObject {

    public static void main(String[] args) {
        Shape s = new Shape();
        Circle c = new Circle();
        Rectangle r = new Rectangle();

        System.out.println(s);
        System.out.println(c);
        System.out.println(r);
    }
}

/*
 * Write output of the program.
 * color: white and filled: false
 * color: white and filled: false
 * color: white and filled: false
 */

/*
 * Answer the following questions.
 * 1. How many Shape objects are created? (tricky question)?
 * Ans: 2 objects
 * 
 * 
 * 2. How many Circle objects are created?
 * Ans: 1
 * 
 * 
 * 3. How many Rectangle objects are created?
 * Ans: 1
 * 
 * 
 */
