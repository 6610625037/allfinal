/**
 *
 * @author 6610685247 <6610685247@cn103>
 */
public class TestTriangle {
    public static void main(String[] args) {
        Shape s = new Shape();
        Circle c = new Circle();
        Rectangle r = new Rectangle();
        Triangle t = new Triangle();

        System.out.println(s);
        System.out.println(c);
        System.out.println(r);
        System.out.println(t);
    }
}
