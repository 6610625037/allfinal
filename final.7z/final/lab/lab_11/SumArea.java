import java.util.Scanner;

/**
 *
 * @author 6610685247 <6610685247@cn103>
 */
public class SumArea {

    // create array of Shape objects
    public static Shape[] createShapeArray(int n) {
        Shape[] shapeArray = new Shape[n];
        for (int i = 0; i < n; i++) {
            double a = Math.random();
            if (a < 0.5) {
                shapeArray[i] = new Rectangle(Math.random() * 10, Math.random() * 10);
            } else {
                shapeArray[i] = new Circle(Math.random() * 10);
            }
        }
        return shapeArray;
    }

    // sum area of all objects in array
    public static double sumArea(Shape[] shapeArray) {
        double sum = 0.0;
        for (int i = 0; i < shapeArray.length; i++) {
            sum += shapeArray[i].getArea();
        }
        return sum;
    }

    // show number of objects for each shape
    public static void printShapeArrayInfo(Shape[] shapeArray) {
        for (int i = 0; i < shapeArray.length; i++) {
            if (shapeArray[i] instanceof Rectangle) {
                Rectangle rec = (Rectangle) shapeArray[i];
                System.out.printf("Rectangle: width = %.2f height = %.2f area = %.2f\n", rec.getWidth(),
                        rec.getHeight(), rec.getArea());
            } else if (shapeArray[i] instanceof Circle) {
                Circle cir = (Circle) shapeArray[i];
                System.out.printf("Circle: radius = %.2f area = %.2f\n", cir.getRadius(), cir.getArea());
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        double totalArea;

        System.out.print("Enter number of objects: ");
        n = sc.nextInt();
        sc.close();

        // create no more than 50 shape objects each
        if (n > 50) {
            return;
        }

        Shape[] shapeArray = createShapeArray(n);

        printShapeArrayInfo(shapeArray);
        totalArea = sumArea(shapeArray);
        System.out.println("Total area: " + String.format("%.2f", totalArea));
    }
}
