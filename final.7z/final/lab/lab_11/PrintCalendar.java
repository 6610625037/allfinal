
/**
 *
 * @author 6610685247 <6610685247@cn103>
 */
import java.util.Scanner;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class PrintCalendar {

    static void printCalendar(int month, int year) {
        Calendar cal = new GregorianCalendar(year, month - 1, 1);
        String[] monthName = new String[] { "January", "Febuary", "March", "April", "May", "June", "July", "August",
                "September", "October", "November", "December" };

        int dayOfFirstWeek = cal.get(Calendar.DAY_OF_WEEK) - 1;
        int dayOfMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        int day = 1;

        System.out.println(monthName[month - 1] + " " + year);
        System.out.println("---------------------------");
        System.out.println("Sun Mon Tue Wed Thu Fri Sat");

        for (int i = 0; i < dayOfFirstWeek; i++) {
            System.out.print("    ");
        }
        while (day <= 7 - dayOfFirstWeek) {
            System.out.printf("%2d  ", day);
            day++;
        }
        System.out.println();
        int weekCount = 1;
        while (day <= dayOfMonth) {
            System.out.printf("%2d  ", day++);
            weekCount++;
            if (weekCount > 7) {
                System.out.println();
                weekCount = 1;
            }

        }
    }

    public static void main(String[] args) {
        int month;
        int year;
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter month: ");
        month = sc.nextInt();
        System.out.print("Enter year : ");
        year = sc.nextInt();
        sc.close();
        printCalendar(month, year);
    }
}
