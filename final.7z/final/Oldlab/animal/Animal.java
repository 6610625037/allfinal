
public abstract class Animal {
    protected int age;
    protected double mass;

    public int getAge() {
        return age;
    }

    public double getMass() {
        return mass;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }

    public abstract String eat();

    public abstract String sound();
}
