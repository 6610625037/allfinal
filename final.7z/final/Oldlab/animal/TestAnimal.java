
import java.util.Scanner;

public class TestAnimal {

    public static void print(Animal animal) {
        String s = "  eat: " + animal.eat() + "\n";
        s += "  sound: " + animal.sound() + "\n";
        System.out.print(s);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int age;
        double mass;
        String color;
        System.out.print("Enter cat info (age mass color): ");
        age = sc.nextInt();
        mass = sc.nextDouble();
        color = sc.next().trim();
        Cat cat = new Cat(age, mass, color);

        System.out.print("Enter fish info (age mass color): ");
        age = sc.nextInt();
        mass = sc.nextDouble();
        color = sc.next().trim();
        Fish fish = new Fish(age, mass, color);
        System.out.println();

        System.out.println("Cat: " + cat);
        print(cat);
        System.out.println("  move: " + cat.howToMove());
        System.out.println();

        System.out.println("Bird: " + fish);
        print(fish);
        System.out.println("  move: " +fish.howToMove());
        System.out.println();

        System.out.print("Change cat (age mass color): ");
        age = sc.nextInt();
        mass = sc.nextDouble();
        color = sc.next().trim();
        cat.setAge(age);
        cat.setMass(mass);
        cat.setColor(color);

        System.out.print("Change fish (age mass color): ");
        age = sc.nextInt();
        mass = sc.nextDouble();
        color = sc.next().trim();
        fish.setAge(age);
        fish.setMass(mass);
        fish.setColor(color);

        System.out.println();
        System.out.println("Cat: " + cat);
        System.out.println("Fish: " + fish);

        sc.close();
    }
}
