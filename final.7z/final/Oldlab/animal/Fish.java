
public class Fish extends Animal implements Movable {
    protected String color;

    public Fish(int age, double mass, String color) {
        this.age = age;
        this.mass = mass;
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String eat() {
        return "fish food";
    }

    public String sound() {
        return "fish sound";
    }

    public String howToMove() {
        return "fish move";
    }

    public String toString() {
        return "age: " + age + ", mass: " + mass + ", color: " + color;
    }
}
