
public class Cat extends Animal implements Movable {
    protected String color;

    public Cat(int age, double mass, String color) {
        this.age = age;
        this.mass = mass;
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String eat() {
        return "cat food";
    }

    public String sound() {
        return "cat sound";
    }

    public String howToMove() {
        return "cat move";
    }

    public String toString() {
        return "age: " + age + ", mass: " + mass + ", color: " + color;
    }
}
