
/**
 *
 * @author xxxxxxxxxx@cn103
 *
 */

public interface DomainName {

    public abstract boolean isValid();
}
