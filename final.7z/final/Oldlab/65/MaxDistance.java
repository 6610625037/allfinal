import java.util.Scanner;

public class MaxDistance {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int centreX;
        int centreY;
        int maxX = 0;
        int maxY = 0;
        double distance;
        double maxDistance = 0;

        System.out.print("Enter centre: ");
        centreX = sc.nextInt();
        centreY = sc.nextInt();

        System.out.print("Enter other points: ");
        sc.nextLine();
        String inputLine = sc.nextLine();
        String[] input = inputLine.split(" ");

        for (int i = 0; i < (input.length + 1) / 2; i++) {
            Integer x = Integer.parseInt(input[2 * i]);
            Integer y = Integer.parseInt(input[2 * i + 1]);

            distance = Math.sqrt(Math.pow(x - centreX, 2) + Math.pow(y - centreY, 2));
            if (distance > maxDistance) {
                maxDistance = distance;
                maxX = x;
                maxY = y;
            }
        }
        sc.close();

        System.out.println("Point for max distance: " + maxX + " " + maxY);
        System.out.printf("Max distance: %.1f", maxDistance);
    }
}
