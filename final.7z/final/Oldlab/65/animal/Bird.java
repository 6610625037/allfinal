public class Bird extends Animal implements Movable {
    protected String color;

    public Bird(int age, String color) {
        this.age = age;
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String eat() {
        return "eat: bird food";
    }

    public String sound() {
        return "sound: bird sound";
    }

    public String howToMove() {
        return "move: bird move";
    }

    public String toString() {
        return "age: " + age + ", color: " + color;
    }

}
