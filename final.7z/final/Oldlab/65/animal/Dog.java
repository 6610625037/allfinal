public class Dog extends Animal implements Movable {
    protected String color;

    public Dog(int age, String color) {
        this.age = age;
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String eat() {
        return "eat: dog food";
    }

    public String sound() {
        return "sound: dog sound";
    }

    public String howToMove() {
        return "move: dog move";
    }

    public String toString() {
        return "age: " + age + ", color: " + color;
    }
}
