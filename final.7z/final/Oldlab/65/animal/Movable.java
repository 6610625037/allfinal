/**
 * Movable
 */
public interface Movable {
    public String howToMove();
}