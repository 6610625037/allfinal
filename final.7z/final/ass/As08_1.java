import java.util.Scanner;

public class As08_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int code = sc.nextInt();
        sc.close();

        if (code < 0 || code > 9999) {
            System.out.println("FFFF");
        } else {

            StringBuilder codeText = new StringBuilder(Integer.toString(code));
            while (codeText.length() < 4) {
                codeText.insert(0, "0");
            }

            String output = "";
            if (codeText.toString().matches("(0|2|4|6|8).*")) {
                output = "0" + codeText.toString().substring(1);
            } else {
                String codeTextStr = codeText.toString();
                for (int i = 0; i < codeText.length(); i++) {
                    int a = Integer.parseInt(codeTextStr.substring(i, i + 1));
                    a += 5;
                    if (a >= 10) {
                        a -= 10;
                    }
                    output = output + Integer.toString(a);

                }
            }
            System.out.println(output);
        }
    }
}