import java.util.Scanner;

public class As07_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String word = sc.nextLine();
        sc.close();

        String formatWord = word.replaceAll(" ", "").toLowerCase();
        String firstword;
        String lastword;
        if (formatWord.length() % 2 == 0) {
            firstword = formatWord.substring(0, (formatWord.length() + 1) / 2);
            lastword = formatWord.substring((formatWord.length()) / 2);
        } else {
            firstword = formatWord.substring(0, (formatWord.length() + 1) / 2);
            lastword = formatWord.substring((formatWord.length() - 1) / 2);
        }
        String revLastWord = "";
        for (int i = lastword.length() - 1; i >= 0; i--) {
            revLastWord += lastword.charAt(i);
        }

        if (firstword.equals(revLastWord)) {
            System.out.println("1");
        } else {
            System.out.println(0);
        }
    }
}
