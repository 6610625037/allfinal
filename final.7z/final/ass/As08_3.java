import java.util.Scanner;

public class As08_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        final String[] symbol = new String[] { "I", "V", "X", "L", "C" };
        final int MAX = 100;
        final int MIN = 1;
        int input = sc.nextInt();
        sc.close();
        if (MIN <= input && input <= MAX) {
            String inputStr = String.valueOf(input);
            String output = "";
            for (int i = 0; i < inputStr.length(); i++) {
                int symbolIndex = inputStr.length() - i - 1;
                switch (inputStr.charAt(i)) {
                    case '9':
                        output += addSymbol(symbol[symbolIndex * 2], 1) + addSymbol(symbol[symbolIndex * 2 + 2], 1);
                        break;
                    case '4':
                        output += addSymbol(symbol[symbolIndex * 2], 1) + addSymbol(symbol[symbolIndex * 2 + 1], 1);
                        break;
                    default:
                        int digitValue = Character.getNumericValue(inputStr.charAt(i));
                        if (digitValue >= 5) { // 5,6,7
                            output += addSymbol(symbol[symbolIndex * 2 + 1], 1)
                                    + addSymbol(symbol[symbolIndex * 2], digitValue - 5);
                        } else { // 1,2,3
                            output += addSymbol(symbol[symbolIndex * 2], digitValue);
                        }
                }
            }
            System.out.println(output);
        } else {
            System.out.println("U");
        }
    }

    public static String addSymbol(String symbol, int count) {
        String addedSymbol = "";
        for (int i = 0; i < count; i++) {
            addedSymbol += symbol;
        }
        return addedSymbol;
    }
}
