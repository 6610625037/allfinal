import java.util.Scanner;

public class As07_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String type = sc.next();
        double input = sc.nextDouble();
        double area = 0;

        if (type.equals("r") || type.equals("R")) {
            area = Math.PI * input * input;
        } else if (type.equals("d") || type.equals("D")) {
            area = Math.PI * input * input / 4;
        }
        System.out.printf("%.4f", area);
        sc.close();
    }
}