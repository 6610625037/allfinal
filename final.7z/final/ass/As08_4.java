import java.util.Scanner;

public class As08_4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        sc.close();
        // check for valid input
        final int MAX = 100;
        final int MIN = 1;
        if (MIN <= n && n <= MAX && MIN <= m && m <= MAX) {
            int start = n;
            int stop = m;
            if (m < n) {
                start = m;
                stop = n;
            }
            int[] count = new int[10];
            for (int i = start; i <= stop; i++) {
                String num = String.valueOf(i);
                for (int j = 0; j < num.length(); j++) {
                    String digit = num.charAt(j) + "";
                    count[Integer.parseInt(digit)] += 1;
                }
            }
            for (int k = 0; k < count.length; k++) {
                System.out.println(k + " " + count[k]);
            }
        } else {
            System.out.println("-1");
        }
    }
}
