import java.util.Scanner;

public class As09_4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        sc.close();
        final String keyword1 = "LIVE";
        final String keyword2 = "CHIPMUNKS";
        System.out.println();
        String[] words = input.split(" ");
        int nextIndex = 0;
        for (int i = 0; i < words.length; i++) {
            if (words[i].length() == keyword1.length() || words[i].length() == keyword2.length()) {
                String checkingKeyword = (words[i].length() == keyword1.length()) ? keyword1
                        : keyword2;
                nextIndex = keywordChecking(checkingKeyword, words[i]);
                if (nextIndex != -1)
                    break;
            }
        }

        String newSentence = "";
        for (int j = 0; j < words.length; j++) {
            String word = words[j];
            String newWord = replaceString(word, nextIndex);
            newSentence += newWord;
            if (j != words.length - 1)
                newSentence += " ";
        }
        System.out.println(newSentence);
    }

    public static int keywordChecking(String keyword, String word) {
        int nextIndex = -1;
        for (int i = 0; i <= 26; i++) {
            String newWord = replaceString(word, i);
            if (newWord.equals(keyword)) {
                nextIndex = i;
                break;
            }
        }
        return nextIndex;
    }

    public static String replaceString(String word, int index) {
        String newWord = "";
        for (int j = 0; j < word.length(); j++) {
            char checkingChar = word.charAt(j);
            if (Character.isAlphabetic(checkingChar)) {
                int newIndex = word.charAt(j) + index;
                if (newIndex > 'Z') {
                    newIndex -= 26;
                }
                newWord += (char) (newIndex);
            } else {
                newWord += checkingChar;
            }
        }
        return newWord;
    }
}
