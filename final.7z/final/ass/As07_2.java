import java.util.Scanner;

public class As07_2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double a1 = sc.nextDouble();
        double b1 = sc.nextDouble();
        double c1 = sc.nextDouble();
        double a2 = sc.nextDouble();
        double b2 = sc.nextDouble();
        double c2 = sc.nextDouble();
        sc.close();

        final int MAX = 1000;
        final int MIN = -1000;

        if (!(MIN <= a1 && a1 <= MAX && MIN <= b1 && b1 <= MAX && MIN <= c1 && c1 <= MAX && MIN <= a2 && a2 <= MAX
                && MIN <= b2 && b2 <= MAX && MIN <= c2 && c2 <= MAX)) {
            System.out.println("INVALID");
        } else if (b1 / b2 == a1 / a2 && b1 / b2 == c1 / c2) {
            System.out.println("SAME LINE");
        } else if (b1 / b2 == a1 / a2 && (b1 / b2 != c1 / c2 || a1 / a2 != c1 / c2)) {
            System.out.println("PARALLEL LINES");
        } else {
            double x = (b2 * c1 - b1 * c2) / (b1 * a2 - b2 * a1);
            double y = (a1 * x + c1) / -b1;
            if (x == 0.0) {
                x = Math.abs(x);
            }
            if (y == 0.0) {
                y = Math.abs(y);
            }

            System.out.printf("%.2f %.2f", x, y);

        }

    }
}
