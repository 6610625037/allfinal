import java.util.Scanner;

public class As09_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int count = sc.nextInt();
        sc.nextLine();
        String input = sc.nextLine();
        sc.close();
        String output = "";
        for (int i = 0; i < input.length(); i++) {
            char check = input.charAt(i);
            if (Character.isAlphabetic(check)) {
                int newIndex = check - count;
                if ((Character.isLowerCase(check) && newIndex < 'a')
                        || (Character.isUpperCase(check) && newIndex < 'A')) {
                    newIndex += 26;
                }
                char newChar = (char) (newIndex);
                output += newChar;
            } else {
                output += check;
                continue;
            }
        }
        System.out.println(output);
    }
}
