import java.util.Scanner;

public class As09_2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.next();
        int inputLength = input.length() - 1;
        sc.close();
        String output = "";
        output += input.charAt(0);
        for (int i = 1; i <= inputLength; i++) {
            if (input.charAt(i) == input.charAt(i - 1)) {
                continue;
            } else {
                output += input.charAt(i);
            }
        }
        System.out.println(output);
    }
}
