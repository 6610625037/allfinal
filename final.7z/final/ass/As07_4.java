import java.util.Arrays;
import java.util.Scanner;

public class As07_4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input1 = sc.nextLine();
        String input2 = sc.nextLine();
        sc.close();

        char[] Splited_1 = input1.replaceAll(" ", "").toLowerCase().toCharArray();
        char[] Splited_2 = input2.replaceAll(" ", "").toLowerCase().toCharArray();

        Arrays.sort(Splited_1);
        Arrays.sort(Splited_2);

        if (Arrays.equals(Splited_1, Splited_2)) {
            System.out.println("1");
        } else {
            System.out.println("0");
        }

    }
}
