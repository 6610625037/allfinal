
import java.util.Scanner;
import java.util.Arrays;

public class As09_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        final String[] SPECIAL = new String[] { "a", "an", "at", "for", "i", "in", "of", "on", "the", "to", "with" };

        String text = sc.nextLine();
        sc.close();
        String[] spiltedText = text.split(" ");
        String output = "";

        for (int i = 0; i < spiltedText.length; i++) {
            if (Arrays.asList(SPECIAL).contains(spiltedText[i])) {
                if (i == 0) {
                    String letter = Character.toString(Character.toUpperCase(spiltedText[i].charAt(0)));
                    output += letter;
                } else {
                    continue;
                }
            } else {
                String letter = Character.toString(Character.toUpperCase(spiltedText[i].charAt(0)));
                output += letter;
            }
        }
        System.out.println(output);
    }
}