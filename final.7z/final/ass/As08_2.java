import java.util.Scanner;

public class As08_2 {
    static int checkID(String n) {
        int digit = 13;
        int a = 0;
        for (int i = 0; i < n.length() - 1; i++) {
            a += Integer.parseInt(n.substring(i, i + 1)) * digit;
            digit--;
        }
        int b = a % 11;
        int c = 11 - b;
        int x = c % 10;
        if (Integer.toString(x).equals(n.substring(n.length() - 1, n.length()))) {
            return 1; // True
        } else {
            return 0; // False
        }
    }

    public static void main(String[] args) {
        final long MIN_N = 0L;
        final long MAX_N = 10_000_000_000_000L; // '_' since Java SE 7
        long n;
        int res;
        Scanner sc = new Scanner(System.in);
        n = sc.nextLong();
        sc.close();
        if (n < MIN_N || n >= MAX_N) {
            System.out.printf("INVALID");
            return;
        }
        String nid = Long.toString(n);
        res = checkID(nid); // call method checkID
        System.out.format("%d", res);
    }
}
