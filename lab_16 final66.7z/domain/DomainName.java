
public interface DomainName {

    public abstract boolean isValid();
}
