
import java.util.Scanner;

public class TestDomainName {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a domain name: ");
        String name = sc.nextLine().trim();
        sc.close();

        MyDomainName domainName = new MyDomainName(name);

        boolean res = domainName.isValid();

        System.out.print("\n" + name);
        if (res) {
            System.out.println(" is a valid domain name");
        } else {
            System.out.println(" is NOT a valid domain name");
        }
    }

}
