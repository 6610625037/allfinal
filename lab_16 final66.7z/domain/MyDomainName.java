
public class MyDomainName implements DomainName {
    private String name;

    public MyDomainName(String name) {
        this.name = name;
    }

    public boolean isValid() {
        String[] label = name.split("\\.");
        if (label.length < 2) {
            return false;
        } else {
            for (int i = 0; i < label.length; i++) {
                String test = label[i].replaceAll("[A-Za-z0-9]", "");
                if (test.length() > 0) {
                    return false;
                }
            }

            for (int i = 0; i < label.length; i++) {
                if (label[i].length() == 0) {
                    return false;
                }
            }

            String tldCheck = label[label.length - 1].replaceAll("[A-Za-z]", "");
            if (tldCheck.length() > 0) {
                return false;
            } else {
                return true;
            }
        }
    }
}
