
public class Square extends Shape implements Comparable<Square> {
    public double side;
    public String name;

    public Square() {
        this(1.0, "square");
    }

    public Square(double side, String name) {
        this.side = side;
        this.name = name;
    }

    public double getArea() {
        return side * side;
    }

    public double getPerimeter() {
        return 4 * side;
    }

    public boolean equals(Object obj) {
        if (obj instanceof Square) {
            Square sqr = (Square) obj;
            if (sqr.side == side && sqr.name.length() == name.length()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public void set(double side) {
        this.side = side;
    }

    public void set(String name) {
        this.name = name;
    }

    public void set(double side, String name) {
        this.side = side;
        this.name = name;
    }

    public void set(String name, double side) {
        this.side = side;
        this.name = name;
    }

    public String toString() {
        return "name = " + name + " side = " + side;
    }

    public int compareTo(Square s) {
        if (side > s.side) {
            if (s.name.length() > name.length()) {
                return 1;
            } else {
                return -1;
            }
        } else {
            return -1;
        }
    }
}
