
import java.util.Arrays;
import java.util.Random;

public class TestSquare {

    static final int MAX_OBJS = 4;

    static void print(String prefix,  Square s) {
        System.out.print(prefix);
        System.out.format(" | area: %.1f", s.getArea());
        System.out.format(" | perimeter: %.1f\n", s.getPerimeter());
    }

    public static void main(String[] args) {
        Square[] squares = new Square[MAX_OBJS];
        Square s1, s2, s3, s4, s5;
        int i;
        Random random = new Random(0);

        System.out.print("Created default square: ");
        s1 = new Square();
        System.out.println(s1);

        System.out.print("Create square with 2 parameters: ");
        s2 = new Square(4, "S2");
        System.out.println(s2);

        for (i = 0; i < MAX_OBJS; i++) {
            String name = "SQ" + (i + 1);
            squares[i] = new Square(random.nextInt(50), name);
        }

        System.out.println("\nStarting objects:");
        i = 1;
        for (Square s : squares) {
            print(i + ": " + s, s);
            i++;
        }

        Arrays.sort(squares);

        System.out.println("\nAfter sorting:");
        i = 1;
        for (Square s : squares) {
            print(i + ": " + s, s);
            i++;
        }

        s1 = new Square(2, "NS1");
        s2 = new Square(2, "NS2");
        s3 = new Square(2, "NS3");
        s4 = new Square(2, "NS4");
        s5 = new Square(2, "NS5");

        s1.set(3);
        s2.set("Square2");
        s3.set(4, "Square3");
        s4.set("SQ4", 4);
        s5.set("SQ5", 4);

        System.out.println("\nS1: " + s1);
        System.out.println("S2: " + s2);
        System.out.println("S3: " + s3);
        System.out.println("S4: " + s4);
        System.out.println("S5: " + s5);

        String str1 = s1.equals(s2) ? "" : "NOT ";
        String str2 = s1.equals(s3) ? "" : "NOT ";
        String str3 = s2.equals(s3) ? "" : "NOT ";
        String str4 = s3.equals(s4) ? "" : "NOT ";
        String str5 = s4.equals(s5) ? "" : "NOT ";

        System.out.println("\nS1: " + str1 + "equal S2");
        System.out.println("S1: " + str2 + "equal S3");
        System.out.println("S2: " + str3 + "equal S3");
        System.out.println("S3: " + str4 + "equal S4");
        System.out.println("S4: " + str5 + "equal S5");
    }
}
